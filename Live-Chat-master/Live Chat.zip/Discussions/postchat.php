<?php
		session_start();
		$Cid=$_POST['user'];
		$_SESSION['postuser']=$Cid;
?>
