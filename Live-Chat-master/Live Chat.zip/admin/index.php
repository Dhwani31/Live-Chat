<!DOCTYPE html>
<html>
<head>
	<title>Agent</title>
	<link rel="stylesheet" type="text/css" href="sadmin.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	
</head>

<body>
	<div class='wrap'>
  Login
    <form method='post' id='foo'>
        <input type='text' name='name' class='rem' placeholder='Name'>
        <input type='text' name='email' class='rem' placeholder='E-Mail'>
        <input type="submit" value="LOG IN">
    </form>
</div>
<script type="text/javascript" src="admin.js"></script>
</body>
</html>